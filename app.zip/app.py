# imports
from flask import Flask, render_template, request, send_file
from PIL import Image, ImageEnhance
import random
import zipfile
import io
import shutil
import datetime
import os
import ffmpeg

# create app
app = Flask(__name__)

# create folders if they don't exist
os.makedirs('uploads', exist_ok=True)
os.makedirs('processed', exist_ok=True)
os.makedirs('history', exist_ok=True)

# page routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/image-processor')
def image_processor():
    return render_template('image_processor.html')

@app.route('/video-processor')
def video_processor():
    return render_template('video_processor.html')

@app.route('/history')
def history():
    return render_template('history.html')

# process images
@app.route('/process-images', methods=['POST'])
def process_images():
    images = request.files.getlist('images')
    batch_size = int(request.form.get('batch_size', 5))
    intensity = int(request.form.get('intensity', 30))

    adjust_contrast = 'adjust_contrast' in request.form
    adjust_brightness = 'adjust_brightness' in request.form
    rotate = 'rotate' in request.form
    crop = 'crop' in request.form
    flip_horizontal = 'flip_horizontal' in request.form

    output_folder = os.path.join('processed', datetime.datetime.now().strftime('%Y%m%d%H%M%S'))
    os.makedirs(output_folder, exist_ok=True)

    def scale_range(min_val, max_val):
        factor = intensity / 100
        return random.uniform(min_val * factor, max_val * factor)

    for image_file in images:
        img = Image.open(image_file)
        filename = os.path.splitext(image_file.filename)[0]

        for i in range(batch_size):
            variant = img.copy()

            if adjust_contrast:
                enhancer = ImageEnhance.Contrast(variant)
                factor = 1 + scale_range(-0.1, 0.1)
                variant = enhancer.enhance(factor)

            if adjust_brightness:
                enhancer = ImageEnhance.Brightness(variant)
                factor = 1 + scale_range(-0.1, 0.1)
                variant = enhancer.enhance(factor)

            if rotate:
                angle = scale_range(-5, 5)
                variant = variant.rotate(angle, expand=True)

            if crop:
                width, height = variant.size
                crop_x = int(width * scale_range(0.01, 0.05))
                crop_y = int(height * scale_range(0.01, 0.05))
                variant = variant.crop((crop_x, crop_y, width - crop_x, height - crop_y))

            if flip_horizontal and random.random() > 0.5:
                variant = variant.transpose(Image.FLIP_LEFT_RIGHT)

            output_path = os.path.join(output_folder, f"{filename}_variant_{i+1}.jpg")
            variant.save(output_path, quality=95)

    # Create ZIP
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w') as zipf:
        for root, dirs, files in os.walk(output_folder):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, arcname=file)

    zip_buffer.seek(0)
    shutil.rmtree(output_folder)

    return send_file(
        zip_buffer,
        mimetype='application/zip',
        download_name='processed_images.zip',
        as_attachment=True
    )

# process videos
@app.route('/process-videos', methods=['POST'])
def process_videos():
    videos = request.files.getlist('videos')
    batch_size = int(request.form.get('batch_size', 5))
    intensity = int(request.form.get('intensity', 30))

    adjust_contrast = 'adjust_contrast' in request.form
    adjust_brightness = 'adjust_brightness' in request.form
    rotate = 'rotate' in request.form
    crop = 'crop' in request.form
    flip_horizontal = 'flip_horizontal' in request.form

    output_folder = os.path.join('processed', datetime.datetime.now().strftime('%Y%m%d%H%M%S'))
    os.makedirs(output_folder, exist_ok=True)

    def scale_range(min_val, max_val):
        factor = intensity / 100
        return random.uniform(min_val * factor, max_val * factor)

    for video_file in videos:
        video_path = os.path.join('uploads', video_file.filename)
        video_file.save(video_path)
        filename = os.path.splitext(video_file.filename)[0]

        # Probe original video size
        probe = ffmpeg.probe(video_path)
        video_stream = next(stream for stream in probe['streams'] if stream['codec_type'] == 'video')
        original_width = int(video_stream['width'])
        original_height = int(video_stream['height'])

        # Adjust crop aggressiveness based on batch size
        if batch_size <= 5:
            crop_min = 0.005
            crop_max = 0.015
        elif batch_size <= 10:
            crop_min = 0.01
            crop_max = 0.02
        else:
            crop_min = 0.015
            crop_max = 0.03

        for i in range(batch_size):
            output_path = os.path.join(output_folder, f"{filename}_variant_{i+1}.mp4")

            stream = ffmpeg.input(video_path)

            if adjust_contrast or adjust_brightness:
                contrast = 1 + scale_range(-0.1, 0.1) if adjust_contrast else 1
                brightness = scale_range(-0.05, 0.05) if adjust_brightness else 0
                stream = stream.filter('eq', contrast=contrast, brightness=brightness)

            if rotate:
                angle = scale_range(-2, 2)
                radians = angle * (3.14159265 / 180)
                stream = stream.filter('rotate', radians)

            if crop:
                crop_pixels_x = int(original_width * scale_range(crop_min, crop_max))
                crop_pixels_y = int(original_height * scale_range(crop_min, crop_max))
                crop_w = original_width - crop_pixels_x * 2
                crop_h = original_height - crop_pixels_y * 2

                stream = stream.filter('crop', crop_w, crop_h, crop_pixels_x, crop_pixels_y)
                stream = stream.filter('scale', original_width, original_height)

            if flip_horizontal and random.random() > 0.5:
                stream = stream.filter('hflip')

            stream = ffmpeg.output(stream, output_path, vcodec='libx264', acodec='aac', strict='experimental')
            ffmpeg.run(stream, overwrite_output=True)

        os.remove(video_path)

    # Create ZIP
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w') as zipf:
        for root, dirs, files in os.walk(output_folder):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, arcname=file)

    zip_buffer.seek(0)
    shutil.rmtree(output_folder)

    return send_file(
        zip_buffer,
        mimetype='application/zip',
        download_name='processed_videos.zip',
        as_attachment=True
    )

# run the app
if __name__ == '__main__':
    app.run(debug=True)
